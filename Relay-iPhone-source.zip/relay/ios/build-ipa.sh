#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
xcodebuild -version
mode="${1:-unsigned}"
output="$PWD/build"
mkdir -p "$output"
if [[ "$mode" == unsigned ]]; then
  xcodebuild -project Relay.xcodeproj -scheme Relay -configuration Release -sdk iphoneos \
    -destination 'generic/platform=iOS' -derivedDataPath "$output/derived" \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= ARCHS=arm64 build
  app="$output/derived/Build/Products/Release-iphoneos/Relay.app"
  /usr/libexec/PlistBuddy -c 'Print CFBundleSupportedPlatforms:0' "$app/Info.plist" | /usr/bin/grep -qx iPhoneOS
  /usr/bin/lipo "$app/Relay" -verify_arch arm64
  stage="$(mktemp -d "$output/package.XXXXXX")"
  trap 'python3 -c "import shutil,sys; shutil.rmtree(sys.argv[1],ignore_errors=True)" "$stage"' EXIT
  mkdir "$stage/Payload"
  ditto "$app" "$stage/Payload/Relay.app"
  python3 -c 'import pathlib,sys; pathlib.Path(sys.argv[1]).unlink(missing_ok=True)' "$output/Relay-iPhone-unsigned.ipa"
  (cd "$stage" && /usr/bin/zip -q -r "$output/Relay-iPhone-unsigned.ipa" Payload)
  printf 'Unsigned IPA: %s/Relay-iPhone-unsigned.ipa\nRe-sign with your sideloading tool before installation.\n' "$output"
else
  : "${APPLE_TEAM_ID:?Set APPLE_TEAM_ID}" "${PROFILE_UUID:?Set PROFILE_UUID}"
  [[ "$APPLE_TEAM_ID" =~ ^[A-Z0-9]{10}$ ]] || exit 2
  [[ "$mode" == ad-hoc || "$mode" == app-store-connect ]] || exit 2
  xcodebuild -project Relay.xcodeproj -scheme Relay -configuration Release \
    -destination 'generic/platform=iOS' -archivePath "$output/Relay.xcarchive" \
    CODE_SIGN_STYLE=Manual DEVELOPMENT_TEAM="$APPLE_TEAM_ID" \
    CODE_SIGN_IDENTITY='Apple Distribution' PROVISIONING_PROFILE_SPECIFIER="$PROFILE_UUID" archive
  export RELAY_EXPORT_METHOD="$mode"
  python3 - <<'PY'
import os,plistlib,pathlib
plistlib.dump({'method':os.environ['RELAY_EXPORT_METHOD'],'teamID':os.environ['APPLE_TEAM_ID'],
 'signingStyle':'manual','provisioningProfiles':{'com.iblack.relay.ios':os.environ['PROFILE_UUID']}},
 open('build/ExportOptions.plist','wb'))
PY
  xcodebuild -exportArchive -archivePath "$output/Relay.xcarchive" -exportPath "$output/export" -exportOptionsPlist "$output/ExportOptions.plist"
fi
