# Relay for iPhone

Native SwiftUI app for iOS 17+, connected to Relay's live HTTPS service. Username/password registration, Keychain sessions, direct chats, add by username, incoming bubbles, emoji, drafts, idempotent sends and polling are implemented. No demo fixtures are used. Calling, media, groups, E2EE and account recovery/deletion are not implemented. Relay AI's provider is pending.

## GitHub Actions → IPA

The repository-root `.github/workflows/relay-iphone.yml` uses a macOS runner with Xcode. Open Actions → Build Relay iPhone IPA → Run workflow → unsigned. Download the Relay-iPhone-unsigned artifact after a successful build. It contains a real arm64 iPhone `.ipa`, which needs re-signing with a sideloading tool before installation. Unsigned does not mean directly installable.

For a signed IPA, configure the `ios-signing` GitHub environment with APPLE_TEAM_ID, IOS_DISTRIBUTION_P12_BASE64, IOS_DISTRIBUTION_P12_PASSWORD and IOS_PROVISION_PROFILE_BASE64. Use a distribution profile matching `com.iblack.relay.ios`. Choose ad-hoc for registered devices or app-store-connect for later TestFlight/App Store upload. The workflow exports an IPA; it does not upload it to Apple. Signing credentials are removed from the temporary runner.

Local build: `bash build-ipa.sh unsigned` with full Xcode selected. Local signed export requires APPLE_TEAM_ID and PROFILE_UUID after importing the certificate/profile.

iOS app updates must be installed through the App Store, TestFlight or a sideloading tool. The app cannot silently replace its own iPhone executable. A desktop update script does not apply to iOS.

Validation in this workspace: Swift syntax and Xcode project structure can be checked, but there is no iOS SDK. The Actions workflow must run successfully before an IPA artifact exists. No IPA has been built yet.
