import os,plistlib,pathlib,shutil,re
root=pathlib.Path(os.environ['RUNNER_TEMP'])
with (root/'relay-profile.plist').open('rb') as f:profile=plistlib.load(f)
uid=profile['UUID'];team=os.environ['APPLE_TEAM_ID']
if not re.fullmatch(r'[A-Fa-f0-9-]{36}',uid):raise SystemExit('Invalid provisioning profile UUID')
if profile['TeamIdentifier']!=[team]:raise SystemExit('Provisioning profile team mismatch')
if profile.get('Entitlements',{}).get('application-identifier') not in [team+'.com.iblack.relay.ios',team+'.*']:raise SystemExit('Provisioning profile does not match Relay bundle ID')
folder=pathlib.Path.home()/'Library/MobileDevice/Provisioning Profiles';folder.mkdir(parents=True,exist_ok=True)
path=folder/(uid+'.mobileprovision');shutil.copyfile(root/'relay.mobileprovision',path);path.chmod(0o600)
(root/'relay-profile-path').write_text(str(path))
with open(os.environ['GITHUB_ENV'],'a') as f:f.write('PROFILE_UUID='+uid+'\n')
