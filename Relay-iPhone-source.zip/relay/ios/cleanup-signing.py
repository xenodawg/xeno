import pathlib,os
root=pathlib.Path(os.environ['RUNNER_TEMP'])
p=root/'relay-profile-path'
if p.exists():pathlib.Path(p.read_text()).unlink(missing_ok=True)
for name in ['relay-distribution.p12','relay.mobileprovision','relay-profile.plist','relay-signing.env','relay-profile-path']:(root/name).unlink(missing_ok=True)
