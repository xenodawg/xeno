import Foundation
import SwiftUI

@MainActor final class PhoneStore: ObservableObject {
  @Published private(set) var user: LiveUser?
  @Published private(set) var chats: [LiveConversation] = []
  @Published private(set) var messages: [String: [LiveMessage]] = [:]
  @Published private(set) var drafts: [String: String] = [:]
  @Published private(set) var hasMore: [String: Bool] = [:]
  @Published var error: String?
  @Published private(set) var busy = false
  @Published private(set) var sending = false
  @Published private(set) var remembersSession = true
  var selected: String?
  private let config = try! BackendConfiguration("https://179.66.132.143:9444")
  private lazy var api = LiveAPI(configuration: config)
  private let storage = KeychainSessionStorage()
  private var token: String?
  private var cursor: [String: Int] = [:]
  private var loading: Set<String> = []
  private var refreshing = false
  private var generation = UUID()
  private var file: URL?
  private struct Pending: Codable { let id: String; let text: String }
  private struct Cache: Codable { var drafts: [String: String] = [:]; var pending: [String: Pending] = [:] }
  private var cache = Cache()
  func restore() async {
    guard user == nil, !busy, !UserDefaults.standard.bool(forKey: "skipRestore") else { return }
    busy = true; defer { busy = false }
    do {
      guard let saved = try storage.load(for: config), !saved.isExpired else { return }
      token = saved.accessToken
      try activate(try await api.me(token: saved.accessToken))
      await refresh()
    } catch { token = nil; self.error = "Sign in to continue. " + error.localizedDescription }
  }
  func authenticate(username: String, password: String, register: Bool) async {
    guard !busy else { return }; busy = true; error = nil; defer { busy = false }
    do {
      let handle = username.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
      let auth = try await api.authenticate(username: handle, password: password, displayName: register ? handle : nil, invite: "")
      remembersSession = true
      do { try storage.save(auth.session, for: config) } catch { remembersSession = false }
      UserDefaults.standard.set(!remembersSession, forKey: "skipRestore")
      token = auth.accessToken; try activate(auth.user); await refresh()
    } catch { self.error = error.localizedDescription }
  }
  private func activate(_ account: LiveUser) throws {
    let folder = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
      .appendingPathComponent("Relay").appendingPathComponent(account.id)
    try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
    let url = folder.appendingPathComponent("drafts.json")
    cache = FileManager.default.fileExists(atPath: url.path) ? try JSONDecoder().decode(Cache.self, from: Data(contentsOf: url)) : Cache()
    file = url; drafts = cache.drafts; generation = UUID(); user = account
  }
  private func save() throws {
    guard let file else { return }
    try JSONEncoder().encode(cache).write(to: file, options: [.atomic, .completeFileProtection])
  }
  func draft(_ id: String, _ text: String) {
    cache.drafts[id] = text; drafts[id] = text
    do { try save() } catch { self.error = "Your draft is still open, but could not be saved." }
  }
  func refresh() async {
    guard let token, user != nil, !refreshing else { return }
    refreshing = true; defer { refreshing = false }; let version = generation
    do {
      let result = try await api.conversations(token: token)
      guard version == generation else { return }; chats = result
      if let selected, hasMore[selected] != true { await load(selected) }
    } catch BackendError.signInRequired { clear(); error = "Your session expired. Sign in again. Your drafts are kept." }
    catch { self.error = error.localizedDescription }
  }
  func load(_ id: String) async {
    guard let token, !loading.contains(id) else { return }; let version = generation
    loading.insert(id); defer { loading.remove(id) }
    do {
      let page = try await api.messages(conversation: id, after: cursor[id] ?? 0, token: token)
      guard version == generation else { return }
      var known = Dictionary((messages[id] ?? []).map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
      for message in page.messages { known[message.id] = message }
      messages[id] = known.values.sorted { $0.sequence < $1.sequence }
      cursor[id] = max(cursor[id] ?? 0, page.messages.last?.sequence ?? 0); hasMore[id] = page.hasMore
    } catch { if version == generation { self.error = error.localizedDescription } }
  }
  func add(_ username: String) async -> LiveConversation? {
    guard let token, !busy else { return nil }; busy = true; defer { busy = false }; let version = generation
    do {
      let handle = username.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "@")).lowercased()
      let chat = try await api.start(username: handle, token: token)
      guard version == generation else { return nil }
      if !chats.contains(where: { $0.id == chat.id }) { chats.insert(chat, at: 0) }
      return chat
    } catch { self.error = error.localizedDescription; return nil }
  }
  func send(_ id: String) async {
    guard let token, !sending, let text = drafts[id], !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
    guard text.count <= 4000, text.utf8.count <= 16000 else { error = "Keep messages within 4,000 characters and 16 KB."; return }
    let pending = cache.pending[id]?.text == text ? cache.pending[id]! : Pending(id: UUID().uuidString.lowercased(), text: text)
    cache.pending[id] = pending; let version = generation; sending = true; defer { sending = false }
    do {
      try save()
      let result = try await api.send(conversation: id, id: pending.id, text: text, token: token)
      guard version == generation else { return }
      if !(messages[id] ?? []).contains(where: { $0.id == result.id }) { messages[id, default: []].append(result); messages[id]?.sort { $0.sequence < $1.sequence } }
      cache.pending[id] = nil
      if drafts[id] == text { cache.drafts[id] = ""; drafts[id] = "" }
      try save(); await refresh()
    } catch { if version == generation { self.error = "Send could not be confirmed. Your draft is kept; retrying uses the same message ID. " + error.localizedDescription } }
  }
  func signOut() async {
    guard let token, !busy else { return }; busy = true; defer { busy = false }
    do {
      do { try await api.logout(token: token) } catch BackendError.signInRequired {}
      clear()
    } catch { self.error = error.localizedDescription }
  }
  private func clear() {
    UserDefaults.standard.set(true, forKey: "skipRestore"); try? storage.remove(for: config)
    generation = UUID(); user = nil; token = nil; selected = nil; chats = []; messages = [:]; drafts = [:]; cache = Cache(); cursor = [:]; file = nil
  }
}
