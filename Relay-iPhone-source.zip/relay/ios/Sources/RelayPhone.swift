import SwiftUI
import UIKit

@main struct RelayPhoneApp: App {
  @StateObject private var store = PhoneStore()
  @Environment(\.scenePhase) private var scenePhase
  var body: some Scene {
    WindowGroup {
      Group {
        if store.user == nil { PhoneSignIn() } else { PhoneChats() }
      }.environmentObject(store).tint(.blue)
        .task { await store.restore() }
        .task(id: scenePhase) {
          guard scenePhase == .active else { return }
          while !Task.isCancelled {
            await store.refresh()
            do { try await Task.sleep(for: .seconds(2)) } catch { return }
          }
        }
    }
  }
}
struct PhoneSignIn: View {
  @EnvironmentObject var store: PhoneStore
  @State private var register = true
  @State private var username = ""
  @State private var password = ""
  private var valid: Bool {
    let handle = username.trimmingCharacters(in: .whitespacesAndNewlines)
    return handle.range(of: #"^[A-Za-z0-9_]{3,32}$"#, options: .regularExpression) != nil && (8...256).contains(password.count)
  }
  var body: some View {
    NavigationStack {
      Form {
        Section {
          HStack(spacing: 16) {
            Image("RelayIcon").resizable().frame(width: 64, height: 64)
            VStack(alignment: .leading) { Text("Relay").font(.largeTitle.bold()); Text("Your people. Within reach.").foregroundStyle(.secondary) }
          }.padding(.vertical)
        }.listRowBackground(Color.clear)
        Section {
          TextField("Username", text: $username).textContentType(.username).textInputAutocapitalization(.never).autocorrectionDisabled()
          SecureField("Password · at least 8 characters", text: $password).textContentType(register ? .newPassword : .password)
        } header: { Text(register ? "Create your account" : "Welcome back") } footer: { Text("Usernames use 3–32 letters, numbers or underscores. No server setup or invitation is needed.") }
        if let error = store.error { Section { Text(error).foregroundStyle(.red) } }
        Section {
          Button(register ? "Create Account" : "Sign In") { Task { await store.authenticate(username: username, password: password, register: register) } }.disabled(!valid || store.busy)
          if store.busy { ProgressView() }
          Button(register ? "Already have an account? Sign In" : "Create an Account") { register.toggle(); store.error = nil }.disabled(store.busy)
        }
      }.navigationTitle(register ? "Get started" : "Sign in").navigationBarTitleDisplayMode(.inline)
    }.onDisappear { password = "" }
  }
}
struct PhoneChats: View {
  @EnvironmentObject var store: PhoneStore
  @State private var add = false
  @State private var settings = false
  var body: some View {
    NavigationStack {
      List {
        if store.chats.isEmpty { ContentUnavailableView("Your conversations start here", systemImage: "bubble.left.and.bubble.right", description: Text("Add someone by their username.")) }
        ForEach(store.chats) { chat in
          NavigationLink { PhoneConversation(chat: chat) } label: {
            HStack(spacing: 12) {
              Text(String(chat.peer.displayName.prefix(1))).font(.title3.bold()).frame(width: 42, height: 42).background(.blue.opacity(0.12), in: Circle())
              VStack(alignment: .leading) { Text(chat.peer.displayName).font(.headline); Text("@" + chat.peer.username).font(.caption).foregroundStyle(.secondary) }
            }.padding(.vertical, 4)
          }
        }
      }.navigationTitle("Chats").refreshable { await store.refresh() }
        .toolbar {
          ToolbarItem(placement: .topBarLeading) { Button("Settings", systemImage: "gearshape") { settings = true } }
          ToolbarItem(placement: .topBarTrailing) { Button("Add by Username", systemImage: "person.badge.plus") { store.error = nil; add = true } }
        }
        .sheet(isPresented: $add) { PhoneAddPerson() }
        .sheet(isPresented: $settings) { PhoneSettings() }
    }
  }
}
struct PhoneAddPerson: View {
  @EnvironmentObject var store: PhoneStore
  @Environment(\.dismiss) var dismiss
  @State private var username = ""
  var body: some View {
    NavigationStack {
      Form {
        Section { TextField("Username, with or without @", text: $username).textInputAutocapitalization(.never).autocorrectionDisabled() }
        if let error = store.error { Text(error).foregroundStyle(.red) }
        Button("Add to Chats") { Task { if await store.add(username) != nil { dismiss() } } }.disabled(username.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || store.busy)
      }.navigationTitle("Add by Username").toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } } }
    }
  }
}
struct PhoneConversation: View {
  @EnvironmentObject var store: PhoneStore
  let chat: LiveConversation
  private var items: [LiveMessage] { store.messages[chat.id] ?? [] }
  private var draft: Binding<String> { Binding(get: { store.drafts[chat.id] ?? "" }, set: { store.draft(chat.id, $0) }) }
  var body: some View {
    VStack(spacing: 0) {
      ScrollViewReader { proxy in
        ScrollView {
          LazyVStack(spacing: 14) {
            ForEach(items) { message in
              let outgoing = message.senderID == store.user?.id
              HStack {
                if outgoing { Spacer(minLength: 40) }
                VStack(alignment: outgoing ? .trailing : .leading, spacing: 4) {
                  Text(message.text).textSelection(.enabled).padding(14)
                    .foregroundStyle(outgoing ? Color.white : Color.primary)
                    .background(outgoing ? Color.blue : Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 20))
                    .overlay { if !outgoing { RoundedRectangle(cornerRadius: 20).strokeBorder(Color.secondary.opacity(0.3)) } }
                  HStack(spacing: 4) { Text(Date(timeIntervalSince1970: message.createdAt), style: .time); if outgoing { Text("Sent ✓") } }.font(.caption2).foregroundStyle(.secondary)
                }
                if !outgoing { Spacer(minLength: 40) }
              }.id(message.id)
            }
            if store.hasMore[chat.id] == true { Button("Load Next 100 Messages") { Task { await store.load(chat.id) } } }
            Color.clear.frame(height: 1).id("latest")
          }.padding()
        }.onChange(of: items.count) { _, _ in if items.last?.senderID == store.user?.id { withAnimation { proxy.scrollTo("latest", anchor: .bottom) } } }
      }
      if let error = store.error { Text(error).font(.caption).foregroundStyle(.red).padding(.horizontal) }
    }.navigationTitle(chat.peer.displayName).navigationBarTitleDisplayMode(.inline)
      .safeAreaInset(edge: .bottom) {
        HStack(alignment: .bottom) {
          Menu {
            ForEach(["😀","😂","🥰","😊","😎","👍","👏","🙏","❤️","💙","🔥","🎉"], id: \.self) { emoji in Button(emoji) { draft.wrappedValue += emoji } }
          } label: { Image(systemName: "face.smiling").font(.title2).padding(8) }.accessibilityLabel("Choose Emoji")
          TextField("Message", text: draft, axis: .vertical).lineLimit(1...5).textFieldStyle(.roundedBorder)
          Button { Task { await store.send(chat.id) } } label: { Image(systemName: "arrow.up.circle.fill").font(.largeTitle) }.accessibilityLabel("Send Message")
            .disabled(store.sending || draft.wrappedValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }.padding(12).background(.bar)
      }
      .task { store.selected = chat.id; await store.load(chat.id) }
      .onDisappear { if store.selected == chat.id { store.selected = nil }; store.error = nil }
  }
}
struct PhoneSettings: View {
  @EnvironmentObject var store: PhoneStore
  @Environment(\.dismiss) var dismiss
  var body: some View {
    NavigationStack {
      Form {
        Section("Account") { Text(store.user?.displayName ?? ""); Text("@" + (store.user?.username ?? "")); if !store.remembersSession { Text("Sign in again after closing the app; your session could not be saved securely.") } }
        Section("Updates") { Text("iPhone updates are managed by the App Store, TestFlight, or your sideloading tool. Relay cannot replace its own iOS app binary.") }
        Section("Privacy") { Text("Messages are stored on Relay’s service without end-to-end encryption. Sent confirms server acceptance, not reading. Relay AI’s provider is not configured yet. Calls, media, groups and account recovery/deletion are not implemented.") }
        Button("Sign Out", role: .destructive) { Task { await store.signOut(); if store.user == nil { dismiss() } } }.disabled(store.busy)
      }.navigationTitle("Settings").toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
    }
  }
}
