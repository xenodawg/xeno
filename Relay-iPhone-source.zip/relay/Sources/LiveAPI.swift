import Foundation

struct LiveUser: Codable, Identifiable, Equatable {
  let id: String
  let username: String
  let displayName: String
}
struct LiveAuthentication: Decodable {
  let user: LiveUser
  let accessToken: String
  let expiresAt: Double
  var session: BackendSession {
    BackendSession(userID: user.id, accessToken: accessToken, refreshToken: nil,
                   expiresAt: Date(timeIntervalSince1970: expiresAt))
  }
}
struct LiveConversation: Decodable, Identifiable, Equatable {
  let id: String
  let peer: LiveUser
  let updatedAt: Double
}
struct LiveMessage: Decodable, Identifiable, Equatable {
  let id: String
  let conversationID: String
  let senderID: String
  let text: String
  let createdAt: Double
  let sequence: Int
}
struct LiveMessagePage: Decodable {
  let messages: [LiveMessage]
  let hasMore: Bool
}
private struct LiveConversationList: Decodable { let conversations: [LiveConversation] }
private struct LiveMe: Decodable { let user: LiveUser }

final class LiveAPI {
  let configuration: BackendConfiguration
  private let transport: BackendTransport
  init(configuration: BackendConfiguration) {
    self.configuration = configuration
    transport = BackendTransport(configuration: configuration)
  }
  private func request<T: Decodable>(_ path: [String], token: String? = nil,
    body: [String: String]? = nil, query: [URLQueryItem] = [], key: String? = nil) async throws -> T {
    let bytes = try await transport.request(["v1"] + path, method: body == nil ? "GET" : "POST",
      query: query, body: try body.map { try JSONEncoder().encode($0) }, token: token,
      idempotencyKey: key)
    return try JSONDecoder().decode(T.self, from: bytes)
  }
  func authenticate(username: String, password: String, displayName: String?, invite: String) async throws -> LiveAuthentication {
    var body = ["username": username.lowercased(), "password": password]
    if let name = displayName { body["displayName"] = name }
    return try await request([displayName == nil ? "login" : "register"], body: body)
  }
  func me(token: String) async throws -> LiveUser {
    let response: LiveMe = try await request(["me"], token: token)
    return response.user
  }
  func logout(token: String) async throws {
    _ = try await transport.request(["v1", "logout"], method: "POST", body: Data("{}".utf8), token: token)
  }
  func conversations(token: String) async throws -> [LiveConversation] {
    let response: LiveConversationList = try await request(["conversations"], token: token)
    return response.conversations
  }
  func start(username: String, token: String) async throws -> LiveConversation {
    try await request(["conversations"], token: token, body: ["username": username.lowercased()])
  }
  func messages(conversation: String, after: Int, token: String) async throws -> LiveMessagePage {
    try await request(["conversations", conversation, "messages"], token: token,
      query: [URLQueryItem(name: "after", value: String(after))])
  }
  func send(conversation: String, id: String, text: String, token: String) async throws -> LiveMessage {
    try await request(["conversations", conversation, "messages"], token: token,
      body: ["id": id, "text": text], key: id)
  }
}
