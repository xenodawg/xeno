import Foundation
import Security

/// Provider-neutral transport. Routes and payloads belong to an adapter for the actual backend;
/// this layer deliberately does not invent sign-in, message, or calling endpoints.
struct BackendConfiguration: Equatable, Codable {
  let baseURL: URL

  init(_ address: String) throws {
    guard
      var parts = URLComponents(string: address.trimmingCharacters(in: .whitespacesAndNewlines)),
      let host = parts.host?.lowercased(), !host.isEmpty,
      parts.user == nil, parts.password == nil, parts.query == nil, parts.fragment == nil,
      parts.port.map({ (1...65535).contains($0) }) ?? true
    else { throw BackendError.invalidAddress }
    let loopback = ["localhost", "127.0.0.1", "[::1]", "::1"].contains(host)
    guard
      parts.scheme?.lowercased() == "https" || (parts.scheme?.lowercased() == "http" && loopback)
    else { throw BackendError.insecureAddress }
    parts.host = host
    parts.scheme = parts.scheme?.lowercased()
    guard let url = parts.url else { throw BackendError.invalidAddress }
    baseURL = url
  }

  func endpoint(_ segments: [String], query: [URLQueryItem] = []) throws -> URL {
    guard !segments.isEmpty,
      segments.allSatisfy({
        !$0.isEmpty && $0 != "." && $0 != ".." && !$0.contains("/") && !$0.contains("\\")
          && !$0.contains("%")
      })
    else { throw BackendError.invalidRoute }
    var url = baseURL
    for segment in segments { url.appendPathComponent(segment) }
    guard var parts = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
      throw BackendError.invalidRoute
    }
    if !query.isEmpty { parts.queryItems = query }
    guard let result = parts.url else { throw BackendError.invalidRoute }
    return result
  }
}

enum BackendError: Error, LocalizedError, Equatable {
  case invalidAddress
  case insecureAddress
  case invalidRoute
  case invalidResponse
  case responseTooLarge
  case signInRequired
  case accessDenied
  case missing
  case conflict
  case rateLimited(retryAfter: Int?)
  case redirect
  case unavailable
  case rejected(status: Int)
  case keychain(status: Int32)

  var errorDescription: String? {
    switch self {
    case .invalidAddress:
      return "Enter a server URL without credentials, query parameters, or a fragment."
    case .insecureAddress:
      return "Use HTTPS for your server. HTTP is allowed only for development on this Mac."
    case .invalidRoute: return "The server route is invalid. Check the backend configuration."
    case .invalidResponse: return "The server returned an unexpected response."
    case .responseTooLarge: return "The server response is too large. Try loading a smaller page."
    case .signInRequired: return "Your session has expired. Sign in again to continue."
    case .accessDenied: return "You don’t have permission to do that."
    case .missing: return "This item is no longer available."
    case .conflict: return "This item changed. Refresh it before trying again."
    case .rateLimited(let seconds):
      return seconds.map { "Too many requests. Try again in \($0) seconds." }
        ?? "Too many requests. Try again later."
    case .redirect: return "The server redirected the request. Check the configured server URL."
    case .unavailable:
      return "The server is unavailable. Your input has been kept. Try again shortly."
    case .rejected(let code): return "The server couldn’t complete the request (\(code))."
    case .keychain: return "Relay couldn’t access its saved session in Keychain."
    }
  }
}

struct BackendSession: Codable, Equatable {
  let userID: String
  let accessToken: String
  let refreshToken: String?
  let expiresAt: Date?

  var isExpired: Bool { expiresAt.map { $0 <= Date() } ?? false }
}

protocol SessionStorage {
  func load(for configuration: BackendConfiguration) throws -> BackendSession?
  func save(_ session: BackendSession, for configuration: BackendConfiguration) throws
  func remove(for configuration: BackendConfiguration) throws
}

struct KeychainSessionStorage: SessionStorage {
  private func query(_ configuration: BackendConfiguration) -> [String: Any] {
    [
      kSecClass as String: kSecClassGenericPassword,
      kSecAttrService as String: "com.iblack.relay.backend-session",
      kSecAttrAccount as String: configuration.baseURL.absoluteString,
    ]
  }

  func load(for configuration: BackendConfiguration) throws -> BackendSession? {
    var request = query(configuration)
    request[kSecReturnData as String] = true
    request[kSecMatchLimit as String] = kSecMatchLimitOne
    var value: CFTypeRef?
    let status = SecItemCopyMatching(request as CFDictionary, &value)
    if status == errSecItemNotFound { return nil }
    guard status == errSecSuccess, let bytes = value as? Data else {
      throw BackendError.keychain(status: status)
    }
    return try JSONDecoder().decode(BackendSession.self, from: bytes)
  }

  func save(_ session: BackendSession, for configuration: BackendConfiguration) throws {
    let request = query(configuration)
    let bytes = try JSONEncoder().encode(session)
    let changes: [String: Any] = [kSecValueData as String: bytes]
    var status = SecItemUpdate(request as CFDictionary, changes as CFDictionary)
    if status == errSecItemNotFound {
      var item = request
      item[kSecValueData as String] = bytes
      item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
      status = SecItemAdd(item as CFDictionary, nil)
    }
    guard status == errSecSuccess else { throw BackendError.keychain(status: status) }
  }

  func remove(for configuration: BackendConfiguration) throws {
    let status = SecItemDelete(query(configuration) as CFDictionary)
    guard status == errSecSuccess || status == errSecItemNotFound else {
      throw BackendError.keychain(status: status)
    }
  }
}

private final class NoRedirectDelegate: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
  func urlSession(
    _ session: URLSession, task: URLSessionTask,
    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
    completionHandler: @escaping (URLRequest?) -> Void
  ) {
    // Never forward bearer credentials to a new origin, including through an HTTP downgrade.
    completionHandler(nil)
  }
}

final class BackendTransport: @unchecked Sendable {
  let configuration: BackendConfiguration
  private let session: URLSession
  private let delegate = NoRedirectDelegate()
  private let maximumResponseBytes = 8 * 1024 * 1024

  init(
    configuration: BackendConfiguration, sessionConfiguration: URLSessionConfiguration = .ephemeral
  ) {
    self.configuration = configuration
    sessionConfiguration.httpShouldSetCookies = false
    sessionConfiguration.httpCookieStorage = nil
    sessionConfiguration.urlCache = nil
    sessionConfiguration.timeoutIntervalForRequest = 20
    sessionConfiguration.timeoutIntervalForResource = 30
    session = URLSession(
      configuration: sessionConfiguration, delegate: delegate, delegateQueue: nil)
  }

  deinit { session.invalidateAndCancel() }

  /// No automatic mutation retries: the provider adapter must supply a stable idempotency key
  /// when its documented API supports retrying a send.
  func request(
    _ path: [String], method: String = "GET", query: [URLQueryItem] = [],
    body: Data? = nil, token: String? = nil, idempotencyKey: String? = nil
  ) async throws -> Data {
    try Task.checkCancellation()
    var request = URLRequest(url: try configuration.endpoint(path, query: query))
    request.httpMethod = method
    request.httpBody = body
    request.setValue("application/json", forHTTPHeaderField: "Accept")
    if body != nil { request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
    if let token {
      guard !token.isEmpty, token.utf8.count <= 16384,
        token.utf8.allSatisfy({ (0x21...0x7e).contains($0) })
      else {
        throw BackendError.signInRequired
      }
      request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
    }
    if let key = idempotencyKey {
      guard !key.isEmpty, key.utf8.count <= 256, key.utf8.allSatisfy({ (0x21...0x7e).contains($0) })
      else {
        throw BackendError.invalidRoute
      }
      request.setValue(key, forHTTPHeaderField: "Idempotency-Key")
    }
    let (stream, response) = try await session.bytes(for: request)
    guard let http = response as? HTTPURLResponse else { throw BackendError.invalidResponse }
    switch http.statusCode {
    case 200...299: break
    case 300...399: throw BackendError.redirect
    case 401: throw BackendError.signInRequired
    case 403: throw BackendError.accessDenied
    case 404: throw BackendError.missing
    case 409: throw BackendError.conflict
    case 429:
      throw BackendError.rateLimited(
        retryAfter: http.value(forHTTPHeaderField: "Retry-After").flatMap(Int.init))
    case 500...599: throw BackendError.unavailable
    default: throw BackendError.rejected(status: http.statusCode)
    }
    if response.expectedContentLength > maximumResponseBytes { throw BackendError.responseTooLarge }
    var result = Data()
    for try await byte in stream {
      guard result.count < maximumResponseBytes else { throw BackendError.responseTooLarge }
      result.append(byte)
    }
    return result
  }
}
